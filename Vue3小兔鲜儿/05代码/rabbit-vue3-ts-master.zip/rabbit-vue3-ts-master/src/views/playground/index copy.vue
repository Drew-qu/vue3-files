<script lang="tsx">
export default {
  render() {
    // 通过h函数创建
    return (
      <div>
        <p>123</p>
        <span>123</span>
        <button>哈哈哈</button>
      </div>
    )
  },
}
</script>
